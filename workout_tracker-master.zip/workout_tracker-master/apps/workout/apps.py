from django.apps import AppConfig


class WorkoutConfig(AppConfig):
    name = 'workout'
